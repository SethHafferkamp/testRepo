

const defaultFileName = './bigFile.txt';
const defaultIndexFileName = './index.txt';

module.exports = {defaultFileName, defaultIndexFileName};