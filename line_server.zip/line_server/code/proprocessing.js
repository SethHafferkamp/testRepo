const fs = require('fs');

const byteChunkSize = 512 * 512;

const {defaultFileName, defaultIndexFileName} = require('./constants');

function process_file(fileNameParam, indexFileNameParam) {
    let fileName = fileNameParam || defaultFileName;
    let indexFileName = indexFileNameParam || defaultIndexFileName;

    runningLineCount = 0;
    stream = fs.createReadStream(fileName, { highWaterMark: byteChunkSize });
    outFile = fs.createWriteStream(indexFileName);
    stream.on('data', (chunk)=>{
        newLineCount = chunk.toString().match(/\n/g).length;
        runningLineCount += newLineCount;
        outFile.write(`${stream.bytesRead},${runningLineCount}\n`)
    })
}


process_file();

module.exports = {process_file};