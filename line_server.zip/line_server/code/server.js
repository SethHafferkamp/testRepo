const fs = require('fs');
const express = require('express');
const es = require('event-stream');
const bs = require('binarysearch');
const app = express();
const router = express.Router();
const {defaultFileName, defaultIndexFileName} = require('./constants');

globalRowByteCheckpoints = undefined; // A list of tuples of [(byte_offset, line_number_checkpoint), ...]
globalLineNumbers = undefined; // A list of just line numbers copied from from globalRowByteCheckpoints

activeRequests = 0;

router.get('/lines/:lineNumber', function (req, res) {
     // Input is 1-indexed, converting to 0-index arrays
    let lineNumberRequested = parseInt(req.params.lineNumber, 10) - 1;

    activeRequests ++;
    console.log(`Handling ${activeRequests} Active Requests`);

    if (!(globalRowByteCheckpoints && globalLineNumbers)){
        cacheIndexFile(() => sendLineCallback(lineNumberRequested));
    }
    else {
        sendLineCallback(lineNumberRequested);
    }

    function cacheIndexFile(callback) {
        fs.readFile(defaultIndexFileName, {encoding: 'utf8'}, (err, data) => {
            if (err) throw err;
            globalRowByteCheckpoints = data.split('\n')
                .filter(x => x.length)
                .map(byteLineNumberTuple => byteLineNumberTuple.split(',')
                    .map(intString => parseInt(intString, 10)));
            globalLineNumbers = globalRowByteCheckpoints.map(byteLineNumberTuple => byteLineNumberTuple[1]);
            callback();
        });
    }

    function sendLineCallback(lineNumber) {
        let maxLineNumber = globalLineNumbers[globalLineNumbers.length - 1];
        if (lineNumber > maxLineNumber) {
            res.status(413).send(`Max line number exceeded, please request a number between 1 and ${maxLineNumber}`);
        }

        let checkpointIndex = bs.closest(globalLineNumbers, lineNumber) - 1;
        let lastBytes, lastNewLines;

        if (checkpointIndex < 0) {
            [lastBytes, lastNewLines] = [0, 0];
        }
        else {
            [lastBytes, lastNewLines] = globalRowByteCheckpoints[checkpointIndex];
        }

        let counter = lastNewLines;

        let s = fs.createReadStream(defaultFileName, {start: lastBytes})
            .pipe(es.split())
            .pipe(es.mapSync(function (line) {
                if (counter === lineNumber) {
                    s.end();
                    activeRequests--;
                    console.log(`Handling ${activeRequests} Active Requests`);
                    res.status(200).send(line);
                }
                counter ++;
            }));
    }

});


app.use('/', router);

const port = process.env.PORT || 8000;

app.listen(port);
