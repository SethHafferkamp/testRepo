#!/usr/bin/env bash
npm install
node code/proprocessing.js