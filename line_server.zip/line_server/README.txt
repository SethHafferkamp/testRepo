
How does your system work?
------------------------------------------------------------------------------

Default File Name: 'line_server/bigFile.txt'
Default Server endpoint: 'http://localhost:8000/lines/####'
build file: build.sh
run file: run.sh

My server uses node express to server lines from an immutable file, with default name of 'line_server/bigFile.txt'. The filename is
configurable by changing the defaultFileName variable in 'line_server/constants.js'. I preprocess the file into an index file (described below),
the express server then handles the endpoint 'http://localhost:8000/lines/####' by either returning
  200 with the requested line contents, or
  413 if the line number requested exceeds the maximum line number in the file

The filename is currently hard coded in constants.py. This could be extended to be configurable by command line arg, or
supplied in the api requests itself.

Running build.sh will install the npm packages required, as well as pre-processing the file and creating the index.txt file
Running run.sh will start the express server on the default port of 8000

Note: This index.txt file could have also been prepended to the main text file if it is a requirement that no additional files be created.


How will your system perform with a 1 GB file? a 10 GB file? a 100 GB file?
------------------------------------------------------------------------------

The main performance issue I ran into was scaling the server over file size. I used a FileStream to parse the file in chunks,
which solved the issue of not being able to load the entire file into memory. However, even using a FileStream to address the memory issue,
the simplest approach of looping through the file while counting lines took far too long for files over a few megabytes.
Since we were not supposed to put the file in a database, I came up with another way of more quickly indexing lines in large files.

I used a preprocessing step that ran through the file once, and created a small index file.
This index file simply contains a list of (byte offet -> line numbers) tuples.
It is created by opening a FileStream with a set byte size and counting the number of newlines, keeping running totals.

Once the index file has been created, when a line number is requested, we load the index file (which is then cached in global memory for
subsequent requests) and binary search for the closest byte offset to that line number. We then only need to loop through
worst case n/m lines to find the requested line, where n is the total lines in the file and m is the average lines per chunk.
While this is only a constant reduction in complexity, we fine tune performance by balancing the chunk size and the resulting index file size.

I tested this approach with a 1 GB file, and even with a very small index file of 80kb,
I was able to serve up individual requests with essentially no latency (<30 ms locally)

The same approach would scale for a 10 GB file, the index file would simply be 10 times large, but this would not have a large
effect on the average response time since the worst case number of lines to loop through does not increase.

The same is true even for 100GB. Again, the index file would grow, but as long as it fits in memory, searching through the index data is
Log(m) since we binary search it, where m again is the average lines per chunk.



How will your system perform with 100 users? 10000 users? 1000000 users?
------------------------------------------------------------------------------

File I/O is handled with async FileStreams to increase non-blocking behavior for multiple concurrent users.
The system scales fairly well with concurrent users. Because NodeJS is on an event loop, it doesn't have the overhead
of threading and therefore scales well up to ~10,000 users. I tested my server making 10,000 async requests in succession, and while it did slow
down and the response time went up significantly, it was generally able to handle the requests. I did have to change the open file limit
on my OS since each request opens a FileStream. A single node server is unable to scale to 1,000,000 concurrent connections.
You would need to significantly horizontally scale your servers to realistically handle more than 10,000.
One thing I did not have time to try was running a clustered express server, with which you can fork a server process for each core.
This could increase the number of concurrent users, scaling with the number of cores a machine has.



What documentation, websites, papers, etc did you consult in doing this assignment?
------------------------------------------------------------------------------

I used node and express documentation
https://nodejs.org/api/fs.html
http://expressjs.com/en/api.html

and various blog posts such as
http://stackabuse.com/read-files-with-node-js/
https://stackoverflow.com/questions/2496710/writing-files-in-node-js
https://superuser.com/questions/433746/is-there-a-fix-for-the-too-many-open-files-in-system-error-on-os-x-10-7-1

As well as docs for the third-party libraries I used
https://www.npmjs.com/package/binarysearch
https://www.npmjs.com/package/event-stream
https://www.npmjs.com/package/express


What third-party libraries or other tools does the system use? How did you choose each library or framework you used?
------------------------------------------------------------------------------

I chose Express as my node server because it's a lightweight but robust server.

I used other third-party libraries for any need I had that seemed like a unit of code that probably would have been already written and tested.
For example, I needed to binary search through a sorted array for the closest value. Instead of writing and testing a module to do this,
I found an open-source module.


How long did you spend on this exercise? If you had unlimited more time to spend on this, how would you spend it and how would you prioritize each item?
------------------------------------------------------------------------------

I spent several hours (~8 hours) over a few days working on this project. Part of that time was familiarizing myself with nodejs.
Given more time, I would:
Write at least a base set of unit tests
Continue fine tuning performance
Read through


If you were to critique your code, what would you have to say about it?
------------------------------------------------------------------------------

All of the server code is lumped in one file, as this project continued to grow it should be refactored. The code concerned with reading files
should be extracted from the actual server code handling the endpoints.
Given more time I would write at least a set of unit tests on the file handling byte offset code
As mentioned above, given more time I would also try running a clustered express server, with which you can fork a server process for each core.

