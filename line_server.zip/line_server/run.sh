#!/usr/bin/env bash
npm start